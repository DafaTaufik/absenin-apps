package com.example.if570_lab_uts_dafataufikallatief_67476.model

data class Absence(
    val imageUrl: String,
    val date: String,
    val time: String,
    val status: String
)